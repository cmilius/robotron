import pygame
import logging
import random

logger = logging.getLogger(__name__)

FAMILY_MEMBERS = ("mom", "dad", "mike")

# CONSTANTS
BUFFER_LENGTH = 20  # Frames, the time delay before the flipbook animation will cycle to the next image
BUFFER = 0  # the counter for buffer, will count to the buffer_length then cycle


class PhysicsEntity(pygame.sprite.Sprite):
    def __init__(self, game, e_type, pos, size):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.e_type = e_type
        self.pos = list(pos)
        self.size = size
        self.rect = pygame.Rect(self.pos[0], self.pos[1], self.size[0], self.size[1])
        self.action = "idle"

        # animation variables, see _iterate_animation_frames() for more information
        self.anim_flipbook = [0, 1, 0, 2]  # controls the animation static image
        self.flipbook_index = 0  # indexes the anim_flipbook list
        self.buffer_length = BUFFER_LENGTH
        self.buffer = BUFFER
        self.anim_length = len(
            self.anim_flipbook
        )  # The number of images in the animation

        # spawn animation variables, used for the enforcer and the tank
        self.block_actions = True  # block movement until the entity has fully spawned
        self.spawn_frames = 6  # the number of animations frames in the spawn
        self.frame_counter = 0
        self.anim_frame_delay = 0

    def update(self, movement=(0, 0)):
        """
        Update the physics entity movement.

        :param movement: Movement in (x, y). Default (0, 0)
        :return: None
        """
        self.move_entity(movement=movement)

    def spawn_animation(self):
        """
        Used for entities with a special spawn, not the normal ConvergenceAnimation.

        :return: None
        """
        # spawn the entity
        self.anim_frame_delay += 1
        if self.anim_frame_delay == 30:
            self.iterate_animation_frames()
            # the dictionary is indexed by a number, indicating the current "frame" of the spawn
            # I did it this way because each piece of the spawn changes size
            self.image = self.game.robotrons_animations.animations[self.e_type][
                str(self.frame_counter)
            ][0]
            # TODO: extract the frame_size of the image to adjust the hitbox as the entity is spawning
            # self.rect = self.game.robotrons_animations.animations[self.e_type][]
            self.frame_counter += 1
            self.anim_frame_delay = 0
            if self.frame_counter == self.spawn_frames:
                self.block_actions = False

    def iterate_animation_frames(self):
        """
        Update the animation frames.
        There are two counters, the buffer and the flipbook index.
        The buffer is the length of time in game frames, while the
        flipbook index is the index for the individual images in the animation.
        :return: None
        """
        self.buffer += 1
        if self.buffer_length == self.buffer:
            self.buffer = 0
            self.flipbook_index += 1
            if self.flipbook_index == self.anim_length:
                self.flipbook_index = 0

    def animate(self, frame_movement):
        """
        Given a list frame_movement, update the entity animations.

        :param list frame_movement: The direction vector the entity is moving in.
        :return: None
        """
        # family member animations should stay here, I think, to avoid copying this code three times
        if self.e_type in FAMILY_MEMBERS or self.e_type == "brain":
            # family and brain both have left/right/up/down movement
            self.iterate_animation_frames()
            if frame_movement[0] > 0:
                self.action = "walk_right"
            elif frame_movement[0] < 0:
                self.action = "walk_left"
            if frame_movement[1] > 0 and not frame_movement[0]:
                self.action = "walk_down"
            elif frame_movement[1] < 0 and not frame_movement[0]:
                self.action = "walk_up"
            if self.e_type in FAMILY_MEMBERS:
                self.image = self.game.human_family_animations.animations[self.e_type][
                    self.action
                ][self.anim_flipbook[self.flipbook_index]]
            elif self.e_type == "brain":
                self.image = self.game.robotrons_animations.animations[self.e_type][
                    self.action
                ][self.anim_flipbook[self.flipbook_index]]

    def move_entity(self, movement=(0, 0)):
        if len(movement) == 4:
            # hero logic is given in a list of len==4, not len==2
            x_dir = movement[1] - movement[0]
            y_dir = movement[3] - movement[2]

            # check out of bounds
            in_bounds = self.check_movement_in_bounds([x_dir, y_dir])
            # only move in that direction if it moves to a valid in-bounds position
            if in_bounds[0]:
                self.pos[0] += x_dir
            if in_bounds[1]:
                self.pos[1] += y_dir

            self.rect.x = self.pos[0]
            self.rect.y = self.pos[1]
            return

        frame_movement = [movement[0], movement[1]]

        self.pos[0] += frame_movement[0]
        self.pos[1] += frame_movement[1]

        self.rect.x = self.pos[0]
        self.rect.y = self.pos[1]

        # update animations
        self.animate(frame_movement)

    def check_movement_in_bounds(self, frame_movement):
        """
        Check that the given movement is within the bounds of the active area.
        If not, set that direction to False. Return a list of [x, y] in-bounds validity.

        :param frame_movement: The current frame_movement
        :return: in-bounds truth table
        """

        in_bounds = [True, True]

        if self.rect.right + frame_movement[0] > self.game.active_area.right:
            in_bounds[0] = False
        if self.rect.left + frame_movement[0] < self.game.active_area.left:
            in_bounds[0] = False
        if self.rect.top + frame_movement[1] < self.game.active_area.top:
            in_bounds[1] = False
        if self.rect.bottom + frame_movement[1] > self.game.active_area.bottom:
            in_bounds[1] = False

        return in_bounds

    def direction_to_target(self, target_pos):
        """
        Given a target position, return a vector torwards that position.
        :return: (x, y) vector
        """
        target_pos = list(target_pos)
        # Determine the entity_position
        e_pos = (self.rect.x, self.rect.y)

        frame_movement = [0, 0]  # init

        # x-movement logic
        if target_pos[0] > e_pos[0]:
            frame_movement[0] = 1
        elif target_pos[0] < e_pos[0]:
            frame_movement[0] = -1
        # y-movement logic
        if target_pos[1] > e_pos[1]:
            frame_movement[1] = 1
        elif target_pos[1] < e_pos[1]:
            frame_movement[1] = -1

        return frame_movement

    def move_to_target(self, target_pos, movement=(0, 0), scaler=1, move_dir=None):
        """
        Move the entity torward the target.

        :param target_pos: [x, y] position for the entity to move torwards
        :param movement: default movement (0, 0)
        :param float scaler: Scales how fast the enemy moves in relation to the target.
        :param str or None move_dir: "x" or "y". Selects which direction the entity will move in.
        :return: None
        """
        target_pos = list(target_pos)

        frame_movement = list(self.direction_to_target(target_pos))

        # scale the movement, can be used later to increase difficulty if desired.
        frame_movement = [frame_movement[0] * scaler, frame_movement[1] * scaler]

        if move_dir is not None:
            if move_dir == "x":
                frame_movement[1] = 0
            elif move_dir == "y":
                frame_movement[0] = 0
            else:
                logger.warning(
                    f"Movement direction input must be either 'x' or 'y'. Current input: {move_dir}"
                )

        self.move_entity(movement=frame_movement)

    def move_to_center(self):
        """
        Move the entity to the center of the screen.

        :return: None
        """
        cent_y = self.game.active_area.height // 2
        cent_x = self.game.active_area.width // 2
        hero_x = self.rect.x
        hero_y = self.rect.y
        self.move_entity(movement=[cent_x - hero_x, cent_y - hero_y])

    def reached_target(self, target_pos):
        """
        Determine if the entity has reached it's target position within a given tolerance.
        If target reached, return new target_pos. Else, return the same target_pos
        :param target_pos: Target entity position
        :return: [x, y]
        """
        if (
            abs(self.pos[0] - target_pos[0]) < 2
            and abs(self.pos[1] - target_pos[1]) < 2
        ):
            # calculate new target posit
            target_pos = self.random_movement()
        return target_pos

    def random_movement(self):
        """
        Pick a new position for the hulk to travel to.

        :return: [x, y]
        """
        posit = [
            random.choice(range(self.game.active_area.width)),
            random.choice(range(self.game.active_area.height)),
        ]
        return posit

    def hit_by_projectile(self, **kwargs):
        """
        Default enemy behaviour from being hit by a hero projectile is to remove it from groups with kill()

        :return: None
        """
        self.kill()
