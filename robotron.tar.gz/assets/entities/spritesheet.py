import pygame
import json

class SpriteSheet:
    def __init__(self, filename):
        """
        Initialize the sprite sheet with the given filename. 
        You must ensure there is a .json file with the same name as the .png file
        containing the necessary metadata for the sprite sheet.

        :param filename: Relative path to the sprite sheet image file
        """
        
        self.sprite_sheet = pygame.image.load(filename).convert_alpha() #convert_alpha allows for transparency
        self.animations = {}

        # Load the meta data for the sprite sheet
        self.meta_data = filename.replace('png', 'json')
        with open(self.meta_data) as f:
            self.data = json.load(f)

        # Parse the sprite sheet for each entity found in the json file
        for entity_name, entity_data in self.data['entities'].items():
            self.animations[entity_name] = {}
            for animation_name, animation_data in entity_data['animations'].items():
                # Save the necessary frames for each animation
                self.animations[entity_name][animation_name] = self.get_sprites(
                    animation_data['frame_data']['x'],
                    animation_data['frame_data']['y'],
                    animation_data['frame_data']['w'],
                    animation_data['frame_data']['h'],
                    animation_data['rows'],
                    animation_data['cols'],
                    animation_data['frame_padding']['x'],
                    animation_data['frame_padding']['y']
                )

    def get_sprite(self, x, y, width, height):
        """Get a single sprite from the sprite sheet.
        
        :return: Sprite surface
        """

        sprite = pygame.Surface((width, height)).convert()              # define an empty surface
        sprite.blit(self.sprite_sheet, (0, 0), (x, y, width, height))   # copy the sprite from the sprite sheet to the surface
        return sprite                                                   # return the surface
    
    def get_sprites(self, x, y, width, height, rows, cols, x_padding=0, y_padding=0):
        """Get a grid of sprites from the sprite sheet.
        
        :return: List of sprite surfaces
        """

        # TODO: Right now this only works for a grid of same-size sprites. This may need updated if the sprites in the sheet aren't uniform in size.
        sprites = []        
        for row in range(rows):
            #row padding
            if row > 0:
                    y += y_padding

            for col in range(cols):
                #column padding
                if col > 0:
                    x += x_padding

                sprite = self.get_sprite(x + col * width, y + row * height, width, height)
                sprites.append(sprite)
        return sprites

    def parse_sprites(self, entity_name):
        """Parse the sprite sheet for a specific entity.
        
        :return: List of sprite surfaces
        """

        sprite = self.data[self.meta_data.rsplit('/', 1)[1]][entity_name]
        sprite_frame = sprite['frame']
        return self.get_sprites(sprite_frame['x'], sprite_frame['y'], sprite_frame['w'], sprite_frame['h'], sprite['rows'], sprite['cols'], sprite['padding']['x'], sprite['padding']['y'])
