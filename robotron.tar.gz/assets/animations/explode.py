import pygame

# CONSTANTS
ANIMATION_DURATION = 1000 # ms, total duration of the explode animation
DISPLACEMENT_SPEED = 25  # the speed of the displaced slices during the animation
SLICE_COUNT = 5  # The number of slices to explode into, for each respective direction

class ExplodeAnimations:
    """
    Animate sprite explosions by splitting an image into slices and animating their expansion
    based on the specified direction and mirroring.
    """
    def __init__(self, game, sprite, explode_logic=("horizontal", False)):
        self.game = game
        self.sprite = sprite
        self.explode_logic = explode_logic  # [direction, mirror flag]
        self.start_time = pygame.time.get_ticks()
        self.duration = ANIMATION_DURATION
        self.finished = False
        self.displacement = DISPLACEMENT_SPEED
        self.alpha_start = 255  # The initial opacity value of the slices (fully opaque)
        self.alpha_end = 0  # The final opacity value of the slices (fully transparent)

        self.vertical_slices = []  # List of dictionaries representing the vertical slices of the sprite
        self.horizontal_slices = []  # List of dictionaries representing the horizontal slices of the sprite

        self.pos_x = self.sprite.pos[0]
        self.pos_y = self.sprite.pos[1]

        self.slice_count = SLICE_COUNT
        self.center_index = self.slice_count // 2  # The index of the center slice, used for calculating movement speeds

        img_width, img_height = sprite.image.get_size()
        slice_width = img_width // self.slice_count
        slice_height = img_height // self.slice_count

        for i in range(self.slice_count):
            # vertical slices
            if i == self.slice_count - 1:
                # if i is the the last index piece, take the remaining width of the image
                width = img_width - (i * slice_width)
            else:
                width = slice_width
            rect = pygame.Rect(i * slice_width, 0, width, img_height)
            surf = sprite.image.subsurface(rect).copy()
            self.vertical_slices.append({"surf": surf, "rect": rect.copy(), "dir": "h", "index": i})

        for i in range(self.slice_count):
            # horizontal slices
            if i == self.slice_count - 1:
                height = img_height - (i * slice_height)
            else:
                height = slice_height
            rect = pygame.Rect(0, i * slice_height, img_width, height)
            surf = sprite.image.subsurface(rect).copy()
            self.horizontal_slices.append({"surf": surf, "rect": rect.copy(), "dir": "v", "index": i})

    def animate_slices(self):
        now = pygame.time.get_ticks()
        elapsed = now - self.start_time
        t = min(elapsed / self.duration, 1.0)
        self.finished = t >= 1.0  # finished flag if time is > 1 second

        # Determine which slices to animate based on the explode_direction
        if self.explode_logic[0] == "horizontal":
            slice_lists = [self.vertical_slices]
        elif self.explode_logic[0] == "vertical":
            slice_lists = [self.horizontal_slices]
        elif self.explode_logic[0] == "diagonal":
            slice_lists = [self.horizontal_slices]

        for slice_list in slice_lists:
            for s in slice_list:
                # iterate through each image slice from the original entity
                surf = s["surf"]
                rect = s["rect"]
                # Calculate the opacity value based on elapsed time
                alpha = int(self.alpha_start * (1 - t) + self.alpha_end * t)
                surf.set_alpha(alpha)

                # Slices further away from the center should move faster than the center slice
                distance_from_center = abs(s["index"] - self.center_index)
                displace_scale = 1 + distance_from_center

                if self.explode_logic[0] == "horizontal" and s["dir"] == "h":
                    # Shrink width, move left/right
                    new_width = max(1, int(rect.width * (1 - t)))
                    new_surf = pygame.transform.scale(surf, (new_width, rect.height))
                    shift = int(self.displacement * displace_scale * t)

                    # rect.x is the new position of the image slice
                    # self.pox_x is the original position of the entity, necessary to place the splices in the correct position
                    # shift is the displacement rate. Slices further away from center move at a faster rate
                    self.game.display.blit(new_surf, (rect.x + self.pos_x - shift, rect.y + self.pos_y))
                    self.game.display.blit(new_surf, (rect.x + self.pos_x + shift, rect.y + self.pos_y))

                elif self.explode_logic[0] == "vertical" and s["dir"] == "v":
                    # Shrink height, move up/down
                    new_height = max(1, int(rect.height * (1 - t)))
                    new_surf = pygame.transform.scale(surf, (rect.width, new_height))
                    shift = int(self.displacement * displace_scale * t)

                    self.game.display.blit(new_surf, (rect.x + self.pos_x, rect.y + self.pos_y - shift))
                    self.game.display.blit(new_surf, (rect.x + self.pos_x, rect.y + self.pos_y + shift))

                elif self.explode_logic[0] == "diagonal" and s["dir"] == "v":
                    # Shrink both, move diagonally
                    new_height = max(1, int(rect.height * (1 - t)))
                    new_width = max(1, int(rect.width * (1 - t)))
                    new_surf = pygame.transform.scale(surf, (new_width, new_height))
                    shift = int(self.displacement * displace_scale * t)

                    # Mirrored diagonal
                    if self.explode_logic[1]:
                        self.game.display.blit(new_surf, (rect.x + self.pos_x + shift, rect.y + self.pos_y - shift))
                        self.game.display.blit(new_surf, (rect.x + self.pos_x - shift, rect.y + self.pos_y + shift))
                    # Normal diagonal
                    else:
                        self.game.display.blit(new_surf, (rect.x + self.pos_x - shift, rect.y + self.pos_y - shift))
                        self.game.display.blit(new_surf, (rect.x + self.pos_x + shift, rect.y + self.pos_y + shift))